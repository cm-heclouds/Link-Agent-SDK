/*************************************************************************
* Copyright (c), 2012~2015 iot.10080.cn All Rights Reserved
* @file               LAnet.h
* @description        This is link agent api, for developers using link agent   
* @author             Wu Bizao
* @date               2015/10/22
* @version            1.0.0
* @Revision History :
*                     Date        Author     Version     Notes
*                     2015/10/22  Wu Bizao   1.0.0       Created
 ************************************************************************/


/*****HOW to use this api to develop your project based on link agent****/
/* 
 * this api includes two parts : Timer api and Link Agent Core API
 * 1. include this head file in your code like this : #include "LAnet.h"
 * 1. define pLinkAgent type data like this : pLinkAgent GatewayLA = NULL   
 * 2. init link agent pointer like this : LINK_AGENT_GET_INSTANCE(GatewayLA)
 * 3. init link agent like this : GatewayLA->pinitialize(GatewayLA, "configFileTest", NULL)
 * 4. recive and send data like this : GatewayLA->pgetLinkAgentRecvMsg(GatewayLA) OR GatewayLA->paddLinkAgentSendMsg(GatewayLA, &SendData)
 * 5. destroy link agent instance like this : LINK_AGENT_DESTROY_INSTANCE(GatewayLA)
 */


#ifndef _LANET_H
#define _LANET_H

#ifdef _cplusplus
extern "C"{
#endif

/* WARNING : PLEASE DO NOT MODIFY IT FOR ANY REASON, IT IS FOR INTERNAL USE!!! */
#include "LAnet.inc"

/*************************Link Agent API START*******************************/
/**/
/****/
/******/
/********/
/**************/


/*****************************************************************************/
/* Timer API                                                                 */
/*****************************************************************************/

/* timer id */
typedef int pthreadTimerID;

/* timer type : 0 - one shot timer, 1 - repeating timer */
typedef enum  
{  
	PTHREAD_TIMER_ONCE = 0,
	PTHREAD_TIMER_REPEAT,
} pthreadTimerType;

/* timer callback function */
typedef void(* pthreadTimerCB)(void const *arg);

/*
 * @breif  : create a timer
 * @input  : timer_isr - timer callback fun; type - timer type; arg - argument
 * @return : timer id
 */
extern pthreadTimerID pthreadCreateTimer(pthreadTimerCB timer_isr, pthreadTimerType type, void* arg);
/*
 * @breif  : start a timer
 * @input  : id - timer id; milliSec - timer interval
 * @return : void
 */
extern void pthreadStartTimer(pthreadTimerID id, uint32 milliSec); 
/*
 * @breif  : stop a timer
 * @input  : id - timer id;
 * @return : void
 */
extern void pthreadStopTimer(pthreadTimerID id); 
/*
 * @breif  : delete a timer
 * @input  : id - timer id;
 * @return : void
 */
extern void pthreadDeleteTimer(pthreadTimerID id); 



/*****************************************************************************/
/* Link Agent Core API                                                       */
/*****************************************************************************/

/* use this structure initialize a link agent pointer in your code */
typedef struct _linkAgent{
    /* PUBLIC */
    /* init link agent */
	linkAgentErrCode (*pinitialize)(struct _linkAgent* pthis, int8* configFileName, appJsonConstructor constructor);
    /* send data */
	boolValue (*paddLinkAgentSendMsg)(struct _linkAgent*  pthis, pLASendData pAppData);
    /* receive data */
    pLARecvBufElem (*pgetLinkAgentRecvMsg)(struct _linkAgent*  pthis);

	/* PRIVATE */
    /* the following is linkAgent private data, you should not use it directly */
	appJsonConstructor jsonConstructor;
	pDeviceInfo 	pDevInfo;
	pLARecvBuf 		recvBuf;
	pLASendBuf 		sendBuf;
	linkAgentState 	state;
	pDeviceManager 	pLADevManager;
	pDataReporter 	pLADataReporter;

	osTimerID 		linkAgentTimer;
	boolValue		timerTimeOut;

	osThreadHandle msgSendThread;

	boolValue 		initFinshed;

	void* privateData;
}linkAgent, *pLinkAgent;


/* use this MACRO init link agent instance in your code */
#define LINK_AGENT_GET_INSTANCE(pInstance)  \
            do { \
                    pInstance = (pLinkAgent)osAdaptionMemoryAlloc(sizeof(linkAgent));    \
                    assert(pInstance);   \
					memset(pInstance, 0, sizeof(dataReporter));\
					pInstance->pinitialize = initLinkAgent; \
                } while (0)

/* use this MACRO destroy link agent instance in your code */                
#define LINK_AGENT_DESTROY_INSTANCE(pInstance)    \
	do { destoryLinkAgent(pInstance); SAFE_FREE(pInstance); } while(0)

/* you should not call these 2 functions in your code,  just for compile pass */
extern linkAgentErrCode initLinkAgent(pLinkAgent pthis, int8* configFileName, appJsonConstructor constructor);
extern uint32 destoryLinkAgent(pLinkAgent linkAgent);


/**************/
/********/
/******/
/****/
/**/
/*************************Link Agent API END**********************************/




#ifdef _cplusplus
}
#endif

#endif
