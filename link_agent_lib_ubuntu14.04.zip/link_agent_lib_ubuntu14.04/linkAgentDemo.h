#ifndef _LINK_AGENT_DEMO_
#define _LINK_AGENT_DEMO_


#ifdef _cplusplus
extern "C"{
#endif   





#ifdef _cplusplus
}
#endif   


#endif
